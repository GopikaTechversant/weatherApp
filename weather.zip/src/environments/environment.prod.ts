export const environment = {
    production:true,
    apiKey: 'ad12994231b4b88c7a59201128426265',
    apiUrl: 'https://api.openweathermap.org/data/2.5/'
};
